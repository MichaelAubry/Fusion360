#Author-Mike Aubry and Andy Baldwin
#Description-Takes a body and creates a construction point at it's center of mass.

import adsk.core, adsk.fusion, adsk.cam, traceback

# To keep track of our event handlers
handlers = []
# The id of our command, used throughout
commandId = 'CenterOfMassPoint'
# Some other useful globals
app = None
ui  = None

# Event handler for the commandCreated event.
class CommandButtonCreatedEventHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            eventArgs = adsk.core.CommandCreatedEventArgs.cast(args)
            cmd = eventArgs.command
            onDestroy = CommandButtonDestroyHandler()
            cmd.destroy.add(onDestroy)
            # Keep the handler referenced beyond this function
            handlers.append(onDestroy)
    
            # Connect to the execute event.
            onExecute = CommandButtonExecuteHandler()
            cmd.execute.add(onExecute)
            handlers.append(onExecute)
            
            # Get the CommandInputs collection to create new command inputs.            
            inputs = cmd.commandInputs
            
            # Create the selection input for picking components
            # selectionInput = inputs.addSelectionInput(commandId + '_selection', 'Select', 'Basic select command input')
        except:
            if ui:
                ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))


# Event handler for the execute event.
class CommandButtonExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            # Get the command and the inputs
            eventArgs = adsk.core.CommandEventArgs.cast(args)
            cmd = eventArgs.command
            inputs = cmd.commandInputs
                    
            # Get all components in the active design.
            product = app.activeProduct
            design = adsk.fusion.Design.cast(product)
            title = 'Create Center of Mass Point'
            
            
            if not design:
                ui.messageBox('No active Fusion design', title)
                return
            
            # Get the root component of the active design
            rootComp = design.rootComponent
            
            # Get physical properties from component (high accuracy)
            physicalProperties = rootComp.getPhysicalProperties(adsk.fusion.CalculationAccuracy.HighCalculationAccuracy)
            
            # Get center of mass from physical properties
            cog = physicalProperties.centerOfMass
            
            # Check to see if a base feature named "Center of Gravities" exists.
            baseFeature = rootComp.features.itemByName('Center of Gravities')
            if not baseFeature:
                # Create a new base feature.
                baseFeature = rootComp.features.baseFeatures.add()
                baseFeature.name = 'Center of Gravities'
    
                # Begin editing the base feature.
                baseFeature.startEdit()                
                
                # Create a construction point at the COG position.
                constructionPoints = rootComp.constructionPoints
                pointInput = constructionPoints.createInput()
                pointInput.setByPoint(cog)
                pointInput.targetBaseOrFormFeature = baseFeature
                constPoint = constructionPoints.add(pointInput)
                constPoint.name = 'Center of Gravity'
                
                # End the base feature edit.
                baseFeature.finishEdit()
            else:
                # Check that the "Center of Gravity construction point exists.
                cogPoint = rootComp.constructionPoints.itemByName('Center of Gravity')
                
                # Because of a problem with updating an existing point, this current deletes
                # the existing point so the code in the "else" is never executed.
                if cogPoint:
                    cogPoint.deleteMe()
                    cogPoint = None
                
                if not cogPoint:
                    # Create the construction point.
                    # Begin editing the base feature.
                    baseFeature.startEdit()                
                    
                    # Create a construction point at the COG position.
                    constructionPoints = rootComp.constructionPoints
                    pointInput = constructionPoints.createInput()
                    pointInput.setByPoint(cog)
                    pointInput.targetBaseOrFormFeature = baseFeature
                    constPoint = constructionPoints.add(pointInput)
                    constPoint.name = 'Center of Gravity'
                    
                    # End the base feature edit.
                    baseFeature.finishEdit()
                else:
                    # Edit the existing construction point.
                    pointDef = adsk.fusion.ConstructionPointPointDefinition.cast(cogPoint.definition)
                    baseFeature.startEdit()                
                    pointDef.pointEntity = cog
                    baseFeature.finishEdit()
            
        except:
            if ui:
                ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))

# Event handler for the commandDestroy event
class CommandButtonDestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            # When the command is done, terminate the script
            # This will release all globals which will remove all event handlers
            adsk.terminate()
        except:
            if ui:
                ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))
                
def run(context):
    try:
        global app
        app = adsk.core.Application.get()
        global ui
        ui = app.userInterface
        cmdDefs = ui.commandDefinitions
        
        # Create a button command definition.
        commandButton = cmdDefs.itemById(commandId)
        if not commandButton:
            commandButton = cmdDefs.addButtonDefinition(commandId, 'Center of Mass Point', 
                                                        'Find the center of mass point for a body',
                                                        './/Resources')
        
        # Connect to the command created event.
        commandButtonCreated = CommandButtonCreatedEventHandler()
        commandButton.commandCreated.add(commandButtonCreated)
        handlers.append(commandButtonCreated)
        
        # Get the ADD-INS panel in the model workspace. 
        addInsPanel = ui.allToolbarPanels.itemById('SolidScriptsAddinsPanel')
        
        # Add the button to the bottom.
        buttonControl = addInsPanel.controls.addCommand(commandButton)
        
        # Make the button available in the panel.
        buttonControl.isPromotedByDefault = True
        buttonControl.isPromoted = True
        
        commandButton.execute()
        
        adsk.autoTerminate(False)

    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))
            
                
def stop(context):
    try:
        # Delete the button definition.
        commandButton = ui.commandDefinitions.itemById('CenterOfMassPoint')
        if commandButton:
            commandButton.deleteMe()
            
        # Get panel the control is in.
        addInsPanel = ui.allToolbarPanels.itemById('SolidScriptsAddinsPanel')
        
        # Get and delete the button control.
        buttonControl = addInsPanel.controls.itemById(commandId)
        if buttonControl:
            buttonControl.deleteMe()

    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))
